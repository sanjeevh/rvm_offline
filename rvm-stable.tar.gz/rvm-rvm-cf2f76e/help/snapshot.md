
    $ rvm snapshot {load,save} filename

Saves or creates a snapshot of the given rvm install. This includes:

* Settings
* Aliases
* Rubies
* Gemsets
* Packages
* Your Default

Ideally to easily maintain a consistent environment among machines
/ to back up your environment.

Please note that this is still considered experimental to a large degree.
