# Java Read Properties

Read java system properties

## Usage

Download [ReadProperties.class](https://github.com/mpapis/java_read_properties/releases/download/1.0.0/ReadProperties.class)(right click - save as) or:

    wget https://github.com/mpapis/java_read_properties/releases/download/1.0.0/ReadProperties.class

Run:

    java ReadProperties java.home

And it will display:

    /usr/lib64/jvm/java-1.7.0-openjdk-1.7.0/jre

## Development

Fork the repository and open pull request with changes.
